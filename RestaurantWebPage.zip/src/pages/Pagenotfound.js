import React from 'react'
import Layout from '../components/Layout'

const Pagenotfound = () => {
  return (
    <Layout>
        <h1>Page not Found</h1>
    </Layout>
  )
}

export default Pagenotfound