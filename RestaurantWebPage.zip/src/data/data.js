import Dosa from '../Images/dosa.jpg';
import Chola from '../Images/chhola.jpg';
import Idli from '../Images/idli.jpg';
import MasalaDosa from '../Images/masala.jpg';
import Paneer from '../Images/paneer.jpg';
import Gujrati from '../Images/gujrati.jpeg';

export const MenuList =[
    {
        name:'Dosa',
        description:'Lorem Ipsum is simply dummy text of the printing and typesetting industry. Lorem Ipsum has been the industry standard dummy text ever since the 1500s, when an unknown printer took a galley of type and  ',
        image:Dosa,
        price: 200
    },
    {
        name:'Chola',
        description:'Lorem Ipsum is simply dummy text of the printing and typesetting industry. Lorem Ipsum has been the industry standard dummy text ever since the 1500s, when an unknown printer took a galley of type and  ',
        image:Chola,
        price: 200
    },
    {
        name:'Idli',
        description:'Lorem Ipsum is simply dummy text of the printing and typesetting industry. Lorem Ipsum has been the industry standard dummy text ever since the 1500s, when an unknown printer took a galley of type and  ',
        image:Idli,
        price: 200
    },
    {
        name:'MasalaDosa',
        description:'Lorem Ipsum is simply dummy text of the printing and typesetting industry. Lorem Ipsum has been the industry standard dummy text ever since the 1500s, when an unknown printer took a galley of type and  ',
        image:MasalaDosa,
        price: 200
    },
    {
        name:'Paneer',
        description:'Lorem Ipsum is simply dummy text of the printing and typesetting industry. Lorem Ipsum has been the industry standard dummy text ever since the 1500s, when an unknown printer took a galley of type and  ',
        image:Paneer,
        price: 200
    },
    {
        name:'Gujrati',
        description:'Lorem Ipsum is simply dummy text of the printing and typesetting industry. Lorem Ipsum has been the industry standard dummy text ever since the 1500s, when an unknown printer took a galley of type and  ',
        image:Gujrati,
        price: 200
    }
];